package main.entity;

/**
 * @param :
 * @author : Jiang Erling
 * @date : created in 2019/10/16
 * @return :
 * @description :各种id的接口
 */
public interface Id {
}
